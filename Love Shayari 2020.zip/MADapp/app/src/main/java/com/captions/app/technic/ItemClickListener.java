package com.captions.app.technic;

import android.view.View;

public interface ItemClickListener {
    void onItemClick(View v, int pos);
}
